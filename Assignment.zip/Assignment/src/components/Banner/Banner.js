import React from "react";
import BannerImg from "./BannerImg.jpg";
import BannerSearch from "./BannerSearch/BannerSearch";
import "./Banner.css";

function Banner() {
  return (
    <>
      <div className="Banner_Container relative">
        <img className="w-full" src={BannerImg} alt="Logo" />
        <BannerSearch />
      </div>
    </>
  );
}

export default Banner;
