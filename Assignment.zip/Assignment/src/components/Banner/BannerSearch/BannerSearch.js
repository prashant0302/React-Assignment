import React from "react";
import "./BannerSearch.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";

function BannerSearch() {
  return (
    <>
      <div className="Banner__Search">
        <div className="Banner__Search--Container">
          <h2>Find Adventures, you want to talk about,</h2>
          <div className="relative">
            <input type="text" placeholder="Search Tour" />
            <FontAwesomeIcon
              className="absolute Search__Icon"
              icon={faSearch}
            />
          </div>
        </div>
      </div>
    </>
  );
}

export default BannerSearch;
