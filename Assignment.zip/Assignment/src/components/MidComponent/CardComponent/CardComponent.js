import React from "react";
import "./CardComponent.css";

function CardComponent(props) {
  return (
    <>
      <div className="CardContainer gap-20">
        <div className="Card__Img">
          <img src={props.imgsrc} className="w-full" alt="card1" />
        </div>
        <div className="Card__Body p-15 ">
          <h2 className="material-title-large mt-0">{props.cardHeading}</h2>
          <p className="material-body-medium mb-0 lineClamp-8">
            {props.description}
          </p>
          <button className="mt-15 py-5 px-10 bg-primary border-0 rounded-5">
            Read More..
          </button>
        </div>
      </div>
    </>
  );
}

export default CardComponent;
