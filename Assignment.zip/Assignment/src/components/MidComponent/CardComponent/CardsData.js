const Sdata = [
  {
    imgsrc:
      "https://www.touropia.com/gfx/d/best-places-to-visit-in-india/rajasthan.jpg",
    cardHeading: "Rajasthan",
    description:
      "Northwest India is where you’ll find the state of Rajasthan, which borders Pakistan and is home to the Thar Desert. Whether you’re interested in Rajput history or views of the Aravallis Mountains, Rajasthan contains some of the best places to visit in India. Jaipur, or the Pink City, is the capital of Rajasthan and a wonderful place to begin your trip.",
  },

  {
    imgsrc:
      "https://www.touropia.com/gfx/d/best-places-to-visit-in-india/agra.jpg",
    cardHeading: "Agra",
    description:
      "Agra is one of the most-visited cities in all of India. Once the capital of the Mughal Empire, Agra is now home to the iconic structure known as the Taj Mahal. The white marble mausoleum was built in the 17th century, and it is widely regarded as a monument of love.",
  },

  {
    imgsrc:
      "https://www.touropia.com/gfx/d/best-places-to-visit-in-india/kerala.jpg",
    cardHeading: "Kerala",
    description:
      "The southwestern state of India known as Kerala is a place of tropical beauty. Palm trees, white sand beaches and eco-tourism are all big reasons to explore the region. Besides its famous backwaters, elegant houseboats and temple festivals, Kerala is also home to Thekkady, a tiger preserve which allows you to admire flora and fauna without crowds.",
  },
];

export default Sdata;
