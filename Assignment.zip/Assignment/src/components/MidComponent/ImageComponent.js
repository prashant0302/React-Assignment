import React from "react";
import midImg from "./BodyImgLeft.webp";

const ImageComponent = () => {
  return (
    <>
      <div className="bodyImg">
        <img src={midImg} alt="BodyImg" />
      </div>
    </>
  );
};

export default ImageComponent;
