import React from "react";
import "./MidLayout.css";
import CardComponent from "./CardComponent/CardComponent";
import ImageComponent from "./ImageComponent";
import Sdata from "./CardComponent/CardsData";

const MidLayout = () => {
  return (
    <>
      <div className="Mid__Container mx-auto relative my-50">
        <h1>Require to Visit</h1>
        <div className="Mid__Container--Container flex gap-20 justify-between">
          <ImageComponent />
          <div className="flex gap-20 flex-wrap">
            {Sdata.map((val) => (
              <CardComponent
                imgsrc={val.imgsrc}
                cardHeading={val.cardHeading}
                description={val.description}
              />
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default MidLayout;
