import React from "react";
import logoImg from "./Retour__logo.png";
import "./LogoComponent.css";

function LogoComponent() {
  return (
    <div className="logo">
      <img src={logoImg} alt="Logo" />
    </div>
  );
}

export default LogoComponent;
