import React from "react";
import LogoComponent from "./Logo/LogoComponent";
import Navigation from "./Navigation/Navigation";
import "./Navbar.css";

const Navbar = () => {
  return (
    <>
      <nav className="MainNav">
        <div className="MainNav__Container mx-auto relative flex">
          <LogoComponent />
          <Navigation />
        </div>
      </nav>
    </>
  );
};

export default Navbar;
