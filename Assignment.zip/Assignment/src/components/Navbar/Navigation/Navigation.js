/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBars } from "@fortawesome/free-solid-svg-icons";
import { NavLink } from "react-router-dom";

const Navigation = () => {
  const [showHamburgerIcon, setHamburgerIcon] = useState(false);
  return (
    <>
      <div
        className={
          showHamburgerIcon ? "Menu__links Mobile--Menu__links" : "Menu__links"
        }
      >
        <ul className="p-0 SiderbarMenu-animate-left">
          <li>
            <NavLink activeClassname="active__class" exact to="/">
              Home
            </NavLink>
          </li>
          <li>
            <NavLink exact to="/About">
              About
            </NavLink>
          </li>
          <li>
            <NavLink exact to="/TourLocator">
              Tour Locator
            </NavLink>
          </li>
          <li>
            <NavLink exact to="/Contact">
              Contact Us
            </NavLink>
          </li>
          <li>
            <button className="submit__Tour__btn">Submit a Tour</button>
          </li>
        </ul>
      </div>
      <div className="hamburger--menu">
        <a href="#" onClick={() => setHamburgerIcon(!showHamburgerIcon)}>
          <FontAwesomeIcon className="absolute Search__Icon" icon={faBars} />
        </a>
      </div>
    </>
  );
};

export default Navigation;
