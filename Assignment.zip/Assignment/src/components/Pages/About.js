import React from "react";
import Banner from "../Banner/Banner";
import AboutDetailComponent from "../About/AboutDetailComponent";

function About() {
  return (
    <>
      <Banner />
      <AboutDetailComponent />
    </>
  );
}

export default About;
