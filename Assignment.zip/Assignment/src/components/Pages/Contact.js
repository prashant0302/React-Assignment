import React from "react";
import Banner from "../Banner/Banner";
import ContactDetailComponent from "../Contact/ContactDetailComponent";

function Contact() {
  return (
    <>
      <Banner />
      <ContactDetailComponent />
    </>
  );
}

export default Contact;
