import React from "react";
import Banner from "../Banner/Banner";
import MidLayout from "../MidComponent/MidLayout";

const Home = () => {
  return (
    <>
      <Banner />
      <MidLayout />
    </>
  );
};

export default Home;
