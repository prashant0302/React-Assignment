import React from "react";
import Banner from "../Banner/Banner";
import TourLocatorComponent from "../TourLocator/TourLocatorComponent";

const TourLocator = () => {
  return (
    <>
      <Banner />
      <TourLocatorComponent />
    </>
  );
};

export default TourLocator;
